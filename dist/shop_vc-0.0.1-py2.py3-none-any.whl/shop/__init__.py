"""Shop, the simple content manager.
"""

__version__ = '0.0.1'
