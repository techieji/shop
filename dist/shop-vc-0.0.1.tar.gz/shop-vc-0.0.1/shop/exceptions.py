class Failure(Exception):
    pass
